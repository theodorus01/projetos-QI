import 'package:flutter/material.dart';
import 'package:pokedex_detalhes/screens/home/home.dart';

void main() {
  runApp(
    MaterialApp(
      title: "Pokedex Detalhes",
      home: Home(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
