package br.com.matheuscosta.pokedex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
