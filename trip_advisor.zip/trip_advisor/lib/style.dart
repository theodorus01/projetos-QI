import 'package:flutter/painting.dart';

Color green = Color(0xFF039B8E);
Color orange = Color(0xFFD98F2B);
Color gray = Color(0xFFA3A3A3);