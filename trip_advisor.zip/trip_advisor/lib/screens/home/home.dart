import 'package:flutter/material.dart';
import 'package:tripadvisor/models/place.dart';
import 'package:tripadvisor/style.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}