package br.com.matheuscosta.tripadvisor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
