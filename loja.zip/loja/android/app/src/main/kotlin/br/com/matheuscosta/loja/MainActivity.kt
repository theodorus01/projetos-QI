package br.com.matheuscosta.loja

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
