package br.com.matheuscosta.alunos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
