import 'package:flutter/material.dart';
import 'package:tudo_gostoso/screens/home/home.dart';

void main() {
  runApp(MaterialApp(
    title: "Tudo Gostoso",
    home: Home(),
    debugShowCheckedModeBanner: false,
  ));
}
