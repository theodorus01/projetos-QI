package br.com.matheuscosta.tudo_gostoso

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
