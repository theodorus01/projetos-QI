package br.com.matheuscosta.pokedex_lista

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
