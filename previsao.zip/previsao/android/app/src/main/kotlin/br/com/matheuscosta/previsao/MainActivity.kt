package br.com.matheuscosta.previsao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
