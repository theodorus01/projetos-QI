import 'package:flutter/painting.dart';

Color grayTheme = Color(0xFF2E3643);
