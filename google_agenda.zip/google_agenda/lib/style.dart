import 'package:flutter/painting.dart';

Color grayTheme = Color(0xFF494D53);
Color grayDivider = Color(0xFFE4E4E4);
Color redTheme = Color(0xFFE83151);
