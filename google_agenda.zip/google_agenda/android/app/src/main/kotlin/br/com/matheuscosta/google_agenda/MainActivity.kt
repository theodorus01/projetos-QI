package br.com.matheuscosta.google_agenda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
